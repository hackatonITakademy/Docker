<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Symfony\Component\Process\Process;

class TreatmentController extends Controller
{
    public function index()
    {
        echo "OK";
    }

    public function execPhpStan()
    {

        $process = new Process('/var/www/api.hackaton/vendor/bin/phpstan analyse /var/www/appliPhp');
        $process->run();

        $content = explode("\n", $process->getOutput());
        return json_encode($content);

    }



    /**
     * Execute PhpCodeSniffer method
     *
     * @return json
     */
    public function execPHPCodeSniffer()
    {

        $rules =   ["PEAR.ControlStructures.MultiLineCondition.NewlineBeforeOpenBrace",
                     "PEAR.NamingConventions.ValidFunctionName.NotCamelCaps",
                     "PEAR.Commenting.FunctionComment.WrongStyle",
                     "PEAR.Commenting.FileComment.Missing",
                     "PEAR.Commenting.ClassComment.Missing",
                     "PEAR.Classes.ClassDeclaration.OpenBraceNewLine",
                     "Generic.WhiteSpace.DisallowTabIndent.TabsUsed",
                     "PEAR.WhiteSpace.ScopeIndent.IncorrectExact",
                     "PEAR.WhiteSpace.ScopeIndent.Incorrect",
                     "Generic.Functions.FunctionCallArgumentSpacing.NoSpaceAfterComma",
                     "PEAR.Functions.FunctionDeclaration.BraceOnSameLine",
                     "PEAR.Commenting.FunctionComment.Missing"];


        $process = new Process('/var/www/api.hackaton/vendor/bin/phpcs --report=json --extensions=php --severity=5 /var/www/appliPhp');
        $process->run();

        $tabResults = json_decode($process->getOutput())->files;

        $tabFinal = $tabResults;

        foreach ($tabResults as $e => $fichier){
            if($fichier->errors == 0){
                unset($tabFinal->{$e});
            }
            else
            {
                foreach($fichier->messages as $f => $message){

                    if($message->type == "WARNING" || in_array($message->source, $rules)){
                        unset($tabFinal->{$e}->{'messages'}[$f]);

                    }
                }
            }
        }

        //dd($tabFinal->{'/var/www/appliPhp/_admin/fpdf_create.php'}->{'messages'});
        dd($tabFinal);
    }

    public function execPhpCbcf()
    {

        $process = new Process('/var/www/api.hackaton/vendor/bin/phpcbf --report=json --extensions=php /var/www/appliPhp/');
        $process->run();

        //$tabResults = json_decode($process->getOutput());
        var_dump($process->getOutput());
    }
}


